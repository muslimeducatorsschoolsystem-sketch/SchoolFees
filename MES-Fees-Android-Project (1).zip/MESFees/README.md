# MES Fees – Android app

Offline fee collection app for **Muslim Educators School System**
(Play Group, Nursery, Kindergarten, Class 1–8). Works on Android 5.0 and newer, no internet needed.

## Get the APK without installing anything (about 5 minutes)

1. Make a free account at github.com and sign in.
2. Click **+** (top right) → **New repository** → name it `MESFees` → **Create repository**.
3. On the new page click **uploading an existing file**. Unzip this folder on your computer and drag
   **everything inside it** (including the hidden `.github` folder) into the page. Click **Commit changes**.
   - If the `.github` folder doesn't upload: click **Add file → Create new file**, type the name
     `.github/workflows/build-apk.yml`, paste the contents of that file, and commit.
4. Open the **Actions** tab. The "Build APK" job starts by itself. Wait until it shows a green tick (3–5 min).
5. Click the finished run, scroll to **Artifacts**, download **MES-Fees-APK**, and unzip it.
   You now have **MES-Fees.apk**.
6. Send the APK to the phone (WhatsApp, USB, Google Drive), tap it, and allow
   "Install unknown apps" when Android asks.

## Or build with Android Studio

Open this folder in Android Studio → wait for it to sync → **Build → Build APK(s)**.

## Using the app

1. **Settings** → enter the monthly fee for each class.
2. **Students** → add students (name, father, class, roll no., parent phone).
3. **Collect** → pick a student and the months, save, then send the receipt on WhatsApp, share it, or print it.
4. **Dues** → see who hasn't paid this month and send WhatsApp reminders.
5. **Settings → Save backup** every week. All data lives only on the phone.
6. At the start of a new school year use **Promote all students**.

The app itself is `app/src/main/assets/index.html` – edit that file to change text, colours or features.
